
module.exports = require("quip-apps-webpack-config");
