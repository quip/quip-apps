import quip from "quip";
import App from "./App.jsx";

class StickyNoteRoot extends quip.apps.RootRecord {
    static getProperties() {
        return {
            stickyNote: StickyNoteRichTextRecord,
            test: TestRecord,
        };
    }
}
quip.apps.registerClass(StickyNoteRoot, "root");

class StickyNoteRichTextRecord extends quip.apps.RichTextRecord {
    static getProperties() {
        return {};
    }
    static getDefaultProperties = () => ({
        RichText_placeholderText: "Add a title",
    });
    supportsComments() {
        return true;
    }
}
quip.apps.registerClass(StickyNoteRichTextRecord, "stickyNote");

class TestRecord extends quip.apps.Record {
    static getProperties() {
        return {};
    }
    static getDefaultProperties = () => ({
        "hello": "world",
    });
    getDom() {
        const el = document.querySelector(".foo");
        console.log("el", el);
        return el;
    }
    supportsComments() {
        return true;
    }
}
quip.apps.registerClass(TestRecord, "testrecord");

quip.apps.initialize({
    initializationCallback: function(rootNode, params) {
        let rootRecord = quip.apps.getRootRecord();
        if (params.isCreation) {
            rootRecord.set("stickyNote", {});
            rootRecord.set("test", {});
        }
        ReactDOM.render(
            <App
                richTextRecord={rootRecord.get("stickyNote")}
                testRecord={rootRecord.get("test")} />,
            rootNode,
        );
    },
});
