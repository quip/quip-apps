import quip from "quip";
import Styles from "./App.less";

export default class App extends React.Component {
    static propTypes = {
        richTextRecord: React.PropTypes.instanceOf(quip.apps.RichTextRecord)
            .isRequired,
        testRecord: React.PropTypes.instanceOf(quip.apps.Record)
            .isRequired,
    };

    onClickDelete = () => {
        this.props.richTextRecord.replaceContent("");
    };

    render() {
        var style = {
            backgroundColor: `${quip.apps.ui.ColorMap.YELLOW.VALUE_LIGHT}`,
            border: `1px solid ${quip.apps.ui.ColorMap.YELLOW.VALUE}`,
            boxShadow: "0 2px 5px 5px rgba(0, 0, 0, 0.1)",
            padding: 10,
        };
        return (
            <div className={Styles.hello} style={style}>
                <quip.apps.ui.RichTextBox
                    record={this.props.richTextRecord}
                    width={280}
                    minHeight={280}
                    maxHeight={280}
                />
                <div style={{
                    position: "absolute",
                    bottom: 10,
                    right: 10,
                    color: "#aaa",
                    fontSize: 12,
                }} onClick={this.onClickDelete}>clear</div>
                <div className={Styles.addComment}
                    ref={el => {
                        this.props.richTextRecord.getDom = () => el;
                    }}>
                    <quip.apps.ui.CommentsTrigger
                        record={this.props.richTextRecord}
                        showEmpty={true}
                    />
                </div>
                <div className="foo" style={{
                    width: 100,
                    height: 100,
                    backgroundColor: "red",
                    margin: "20px 0",
                }} onClick={() => {
                    quip.apps.showComments(this.props.testRecord.getId());
                }}>FOO</div>
            </div>
        );
    }
}

function generateRandomNumeric(min, max) {
    return max - Math.random()*(max-min);
}
